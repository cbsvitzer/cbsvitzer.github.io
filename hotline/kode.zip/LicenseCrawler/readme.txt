The language files (*.lc) are optional.
You can delete the files to save disk space

-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#

Run the LicenseCrawler as an administrator
Navigate to the program folder of the LicenseCrawler.exe 
Right-click the program icon (the .exe file).
Choose Run As Administrator.
If you see a User Account Control prompt, accept it.

-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#

FAQ

Run-Time error '339':
Component 'mscomctl.ocx' or one of its dependencies not correctly registered: a file is missing os invalid

Solution:
Navigate to the program folder of the LicenseCrawler.exe 
Right-click the program icon (the .exe file).
Choose Run As Administrator.
If you see a User Account Control prompt, accept it.

-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#

LicenseCrawler Windows License Key Scanner 
Copyright � Martin Klinzmann, www.klinzmann.name
 
The LicenseCrawler can help you find your own used license keys.
Please note: you can't be sure that the LicenseCrawler will find all license keys, or that the found keys are working,
but most of the time they work fine :-)
 
The LicenseCrawler is provided 'as is' and is 'used as seen' ~ no expression as to fitness of purpose is made.
The decision as to whether you use the LicenseCrawler is yours alone.
By choosing to use the LicenseCrawler, you accept full responsibility for any liability arising out of its use.
You are liable for any damages whatever, including but not limited to, any damages arising out of negligence,
any consequential damages whether foreseeable or not, any economic loss, and any other liability and damages due
to any cause arising from using or obtaining the LicenseCrawler.
The author accepts no responsibility whatsoever for any liability, arising out of you obtaining or using the LicenseCrawler.
You assume the sole risk of acquiring and using the LicenseCrawler.
 
IF YOU DO NOT ACCEPT THESE TERMS AND CONDITIONS DO NOT OBTAIN OR USE THE LICENSECRAWLER.
 
Usage:
  -d [1|2|3] = debug mode write into an auto named logfile.
  -eula = skip Eula
  -run  = autostart (must be used with -eula)
  -ignore = ignore existing destination file
  -save FileName [-ignore] = save found keys into a file
  -exit = Exit application if he is finished (needs -run -eula)
  -reg [HKEY_LOCAL_MACHINE|HKEY_CURRENT_USER] = select registry path
  -cmd = Use command line mode. (no GUI)
  -hide = hide GUI must be used with -eula and -run
  -decode.adobe <key> = Decode Adobe key
  -hideheader = Don't write LicenseCrawler header
 
e.g.
   licensecrawler -save keys.log -ignore -cmd
   licensecrawler -run -eula -save keys.log -ignore -exit
   licensecrawler -run -eula -save keys.log -ignore -exit �hide